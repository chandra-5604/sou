﻿using HtmlAgilityPack;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Net;
using System.Text;
using System.IO;
using System.Reflection.Emit;

namespace SampleApp.Models
{
    public class Store
    {
        public int Id { get; set; }
        public string StoreName { get; set; }
    }
    public class VetDirectory
    {
        public List<Store> StoreList { get; set; }    
        public List<Address> AddressList { get; set; }    
    }
    public class Address
    {
        public int Id { get; set; }
        public string FollowedBy { get; set; }
        public string ZipCode { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public long Mobile { get; set; }
        public string NearBy { get; set; }
    

    public VetDirectory GetVetDirectory(string? zipCode = null, string? city = null, string? state = null)
    {
        var vetDirectory = FetchVetDirectoryData();

        if (zipCode != null)
        {
                vetDirectory.AddressList.Where(address => address.ZipCode == zipCode).ToList();
        }
        if (state != null && city != null)
        {
                vetDirectory.AddressList.Where(address => (address.State == state) && (address.City == city)).ToList();
        }

        return vetDirectory;
    }

    public VetDirectory FetchVetDirectoryData()
    {
          var htmlDoc = LoadWebPageContent("https://www.1800petmeds.com/vetdirectory?horizontalView=true").Result;
          var vetDirectories = new VetDirectory();
            vetDirectories.AddressList = ParseStoreAddressHtml(htmlDoc);
            vetDirectories.StoreList = ParseStoreListHtml(htmlDoc);
            return vetDirectories;
    }

        public static async Task<string> LoadWebPageContent(string webUrl)
        {
            HttpClient client = new HttpClient();
            var response = await client.GetStringAsync(webUrl);
            return response;
        }

        public static List<Store> ParseStoreListHtml(string html)
        {
            HtmlDocument htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml(html);

            var storeDetailsNodes = htmlDoc.DocumentNode.SelectNodes(("//div[@class=\"store-name\"]"));

            // var storeListNodes = programmerLinks.Where(node => node.GetAttributeValue("class", "").Contains("store-name"));
            var storeNameList = new List<Store>();
           foreach(HtmlNode parentNode in storeDetailsNodes)
            {
             foreach(var childNode in parentNode.ChildNodes)
                {
                    storeNameList.Add(new Store { StoreName=childNode.InnerText});
                }
            }

           
            return storeNameList;

        }

        public static List<Address> ParseStoreAddressHtml(string html)
        {
            HtmlDocument htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml(html);

            var storeDetailsNodes = htmlDoc.DocumentNode.SelectNodes("//address");

            // var storeListNodes = programmerLinks.Where(node => node.GetAttributeValue("class", "").Contains("store-name"));
            var storeAddress = new List<Address>();
            foreach (HtmlNode parentNode in storeDetailsNodes)
            {
                string postalCode = string.Empty;
                if (parentNode.ChildNodes[2].InnerText.Trim().Split("\n").Length==3)
                {
                    postalCode = parentNode.ChildNodes[2].InnerText.Trim().Split("\n")[2];
                }

                storeAddress.Add(new Address()
                {
                    ZipCode = postalCode,
                    City = parentNode.ChildNodes[2].InnerText.Trim().Split("\n")[0].Replace(",", ""),
                    State = parentNode.ChildNodes[2].InnerText.Trim().Split("\n")[1],
                    Mobile = Convert.ToInt64(parentNode.SelectSingleNode("./div/span/a").InnerText),
                    FollowedBy = parentNode.SelectSingleNode("./div").InnerText,
                    NearBy = parentNode.LastChild.InnerText


                }) ; 
            }


            return storeAddress;

        }
    }
}
